// GAPINO server - بدون هیچ وابستگی خارجی (فقط Node.js)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,ADMIN_KEY=process.env.ADMIN_KEY||'admin123';
const DATA=path.join(__dirname,'data'),UP=path.join(DATA,'uploads'),DBF=path.join(DATA,'db.json');
fs.mkdirSync(UP,{recursive:true});
let db={users:{},chats:{},msgs:[],settings:{siteName:'گپینو',announce:'',maxUpload:5}};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(DBF,'utf8')))}catch(e){}
if(!db.chats.lobby)db.chats.lobby={id:'lobby',type:'group',name:'🌍 چت عمومی',members:[],admins:[],owner:null,locked:false,pub:true};
let st;const save=()=>{clearTimeout(st);st=setTimeout(()=>fs.writeFile(DBF+'.tmp',JSON.stringify(db),()=>fs.rename(DBF+'.tmp',DBF,()=>{})),300)};
const uid=()=>crypto.randomBytes(6).toString('hex');
const clients=new Map(),COL=['#5ea0ff','#b57bff','#ff6fae','#35d6a4','#ffb347','#4fd8ee','#ff7a59','#9bd94f'];
const pub=u=>({id:u.id,name:u.name,bio:u.bio,color:u.color,avatar:u.avatar,online:!u.hide&&clients.has(u.id),mod:!!u.mod});
const me=u=>Object.assign(pub(u),{blocked:u.blocked,hide:!!u.hide,online:true});
const send=(ws,o)=>{try{ws.sock.write(frame(JSON.stringify(o)))}catch(e){}};
const toUser=(id,o)=>{(clients.get(id)||[]).forEach(w=>send(w,o))};
const toAll=o=>clients.forEach(s=>s.forEach(w=>send(w,o)));
const can=(u,c)=>c.pub||c.members.includes(u.id);
const mems=c=>c.pub?Object.keys(db.users):c.members;
const toChat=(c,o)=>mems(c).forEach(id=>toUser(id,o));
function cv(u,c){let last=null,unread=0;const r=u.read[c.id]||0;
  for(let i=db.msgs.length-1;i>=0;i--){const m=db.msgs[i];if(m.chat!==c.id||m.del)continue;
    if(!last)last=m;if(m.ts>r&&m.from!==u.id)unread++;else if(m.ts<=r)break}
  return{id:c.id,type:c.type,name:c.name,avatar:c.avatar,members:c.pub?[]:c.members,admins:c.admins,owner:c.owner,locked:c.locked,pub:!!c.pub,
    peer:c.type==='dm'?c.members.find(x=>x!==u.id):null,
    last:last&&{text:last.kind==='text'?last.text.slice(0,50):last.kind==='sticker'?'استیکر '+last.text:last.kind==='image'?'📷 تصویر':'📎 فایل',ts:last.ts,from:last.from},unread}}
const pushChat=(c)=>mems(c).forEach(id=>{const u=db.users[id];if(u)toUser(id,{t:'chat',c:cv(u,c)})});
const clean=(s,n)=>String(s==null?'':s).replace(/[\u0000-\u0008\u000B-\u001F]/g,'').trim().slice(0,n);
const okUrl=s=>typeof s==='string'&&/^\/uploads\/[\w.-]+$/.test(s);

// ---------- WebSocket (پیاده‌سازی دستی RFC6455) ----------
function frame(s){const b=Buffer.from(s),l=b.length;let h;
  if(l<126)h=Buffer.from([0x81,l]);else if(l<65536){h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(l,2)}
  else{h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(l),2)}return Buffer.concat([h,b])}
function reader(sock,cb){let buf=Buffer.alloc(0);sock.on('data',c=>{buf=Buffer.concat([buf,c]);
  for(;;){if(buf.length<2)return;const op=buf[0]&15,mk=buf[1]&128;let len=buf[1]&127,o=2;
    if(len===126){if(buf.length<4)return;len=buf.readUInt16BE(2);o=4}else if(len===127){if(buf.length<10)return;len=Number(buf.readBigUInt64BE(2));o=10}
    if(len>1e6){sock.destroy();return}const hl=o+(mk?4:0);if(buf.length<hl+len)return;
    let p=Buffer.from(buf.subarray(hl,hl+len));if(mk){const k=buf.subarray(o,o+4);for(let i=0;i<p.length;i++)p[i]^=k[i&3]}
    buf=buf.subarray(hl+len);
    if(op===8){sock.end();return}if(op===9)sock.write(Buffer.concat([Buffer.from([0x8A,p.length]),p]));else if(op===1)cb(p.toString())}})}

// ---------- HTTP ----------
const MIME={'.html':'text/html;charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp'};
const srv=http.createServer((req,res)=>{
  const url=new URL(req.url,'http://x');
  if(req.method==='POST'&&url.pathname==='/upload'){
    const u=Object.values(db.users).find(x=>x.token===url.searchParams.get('t'));
    if(!u||u.banned){res.writeHead(403);return res.end('{}')}
    const max=db.settings.maxUpload*1048576;let n=0,ch=[];
    req.on('data',c=>{n+=c.length;if(n>max){res.writeHead(413);res.end('{}');req.destroy()}else ch.push(c)});
    req.on('end',()=>{if(n>max)return;const ext=path.extname(url.searchParams.get('name')||'').toLowerCase().replace(/[^.\w]/g,'').slice(0,8);
      const f=uid()+uid()+ext;fs.writeFile(path.join(UP,f),Buffer.concat(ch),()=>{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({url:'/uploads/'+f}))})});
    return}
  if(url.pathname.startsWith('/uploads/')){
    const f=path.join(UP,path.basename(url.pathname)),ext=path.extname(f).toLowerCase();
    return fs.readFile(f,(e,b)=>{if(e){res.writeHead(404);return res.end()}
      res.writeHead(200,{'Content-Type':MIME[ext]&&ext!=='.html'?MIME[ext]:'application/octet-stream','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'",'Cache-Control':'public,max-age=86400'});res.end(b)})}
  fs.readFile(path.join(__dirname,'public','index.html'),(e,b)=>{res.writeHead(200,{'Content-Type':MIME['.html']});res.end(b)});
});
srv.on('upgrade',(req,sock)=>{
  const url=new URL(req.url,'http://x'),key=req.headers['sec-websocket-key'];
  if(url.pathname!=='/ws'||!key)return sock.destroy();
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')+'\r\n\r\n');
  const tk=clean(url.searchParams.get('t'),64);if(tk.length<16)return sock.destroy();
  let u=Object.values(db.users).find(x=>x.token===tk);
  if(!u){const id=uid();u=db.users[id]={id,token:tk,name:'کاربر '+Math.floor(1000+Math.random()*9000),bio:'',color:COL[Math.floor(Math.random()*COL.length)],avatar:'',blocked:[],read:{},created:Date.now()};save()}
  const ws={sock,adm:false,cnt:0,tm:Date.now()};
  if(u.banned){send(ws,{t:'banned'});return sock.end()}
  if(!clients.has(u.id))clients.set(u.id,new Set());clients.get(u.id).add(ws);
  const cl=Object.values(db.chats).filter(c=>can(u,c)).map(c=>cv(u,c));
  send(ws,{t:'init',me:me(u),users:Object.values(db.users).map(pub),chats:cl,settings:{siteName:db.settings.siteName,announce:db.settings.announce,maxUpload:db.settings.maxUpload}});
  if(clients.get(u.id).size===1)toAll({t:'user',u:pub(u)});
  reader(sock,txt=>{let d;try{d=JSON.parse(txt)}catch(e){return}
    if(Date.now()-ws.tm>10000){ws.tm=Date.now();ws.cnt=0}if(++ws.cnt>40)return;
    try{handle(ws,u,d)}catch(e){console.error(e)}});
  const bye=()=>{const s=clients.get(u.id);if(!s)return;s.delete(ws);if(!s.size){clients.delete(u.id);toAll({t:'user',u:pub(u)})}};
  sock.on('close',bye);sock.on('error',bye);
});

// ---------- منطق ----------
function handle(ws,u,d){
  const err=m=>send(ws,{t:'err',m});const adm=ws.adm||u.mod,full=ws.adm;
  const isGA=(c)=>c.owner===u.id||c.admins.includes(u.id)||adm;
  switch(d.t){
  case 'send':{const c=db.chats[d.chat];if(!c||!can(u,c))return;
    if(c.locked&&!isGA(c))return err('گروه قفل است و فقط مدیران می‌توانند پیام بدهند');
    if(c.type==='dm'){const o=db.users[c.members.find(x=>x!==u.id)];if(!o||o.blocked.includes(u.id)||u.blocked.includes(o.id))return err('ارسال پیام ممکن نیست')}
    const kind=['text','sticker','image','file'].includes(d.kind)?d.kind:'text';
    const m={id:uid(),chat:c.id,from:u.id,kind,text:clean(d.text,kind==='sticker'?8:2000),ts:Date.now()};
    if(kind==='text'&&!m.text)return;if(kind==='sticker'&&!m.text)return;
    if(kind==='image'||kind==='file'){if(!okUrl(d.url))return;m.url=d.url;m.fname=clean(d.fname,80)||'file'}
    if(d.reply){const r=db.msgs.find(x=>x.id===d.reply&&x.chat===c.id);if(r&&!r.del)m.reply={id:r.id,from:r.from,text:(r.kind==='text'?r.text:r.kind==='image'?'📷 تصویر':r.kind==='file'?'📎 '+r.fname:r.text).slice(0,60)}}
    db.msgs.push(m);if(db.msgs.length>50000)db.msgs.splice(0,5000);save();
    if(c.type==='dm'&&!c.started){c.started=true;pushChat(c)}
    toChat(c,{t:'msg',m});break}
  case 'del':{const m=db.msgs.find(x=>x.id===d.id);if(!m||m.del)return;const c=db.chats[m.chat];
    if(m.from!==u.id&&!(c&&c.type==='group'&&isGA(c))&&!adm)return;
    m.del=true;m.text='';delete m.url;save();toChat(c,{t:'msgdel',id:m.id,chat:m.chat});break}
  case 'hist':{const c=db.chats[d.chat];if(!c||!can(u,c))return;
    const ms=db.msgs.filter(m=>m.chat===c.id).slice(-100);u.read[c.id]=Date.now();save();
    send(ws,{t:'hist',chat:c.id,msgs:ms});toUser(u.id,{t:'chat',c:cv(u,c)});break}
  case 'dm':{const o=db.users[d.to];if(!o||o.id===u.id)return;
    if(o.blocked.includes(u.id)||u.blocked.includes(o.id))return err('این گفتگو ممکن نیست');
    const id='d_'+[u.id,o.id].sort().join('_');
    if(!db.chats[id])db.chats[id]={id,type:'dm',members:[u.id,o.id],admins:[],owner:null,locked:false};
    send(ws,{t:'chat',c:cv(u,db.chats[id]),open:true});break}
  case 'profile':{const n=clean(d.name,20);if(n.length<2)return err('نام باید حداقل ۲ حرف باشد');
    u.name=n;u.bio=clean(d.bio,120);if(/^#[0-9a-f]{6}$/i.test(d.color))u.color=d.color;
    u.avatar=okUrl(d.avatar)?d.avatar:Array.from(clean(d.avatar,12)).slice(0,2).join('');u.hide=!!d.hide;save();
    toUser(u.id,{t:'me',me:me(u)});toAll({t:'user',u:pub(u)});break}
  case 'block':{const o=db.users[d.user];if(!o||o.id===u.id)return;
    u.blocked=u.blocked.filter(x=>x!==o.id);if(d.v)u.blocked.push(o.id);save();toUser(u.id,{t:'me',me:me(u)});break}
  case 'mkgroup':{const name=clean(d.name,30);if(name.length<2)return err('نام گروه را وارد کنید');
    const ms=[...new Set([u.id,...(Array.isArray(d.members)?d.members:[]).filter(x=>db.users[x]&&!db.users[x].blocked.includes(u.id))])].slice(0,200);
    const id='g_'+uid(),c=db.chats[id]={id,type:'group',name,avatar:'',members:ms,admins:[],owner:u.id,locked:false};
    save();pushChat(c);send(ws,{t:'chat',c:cv(u,c),open:true});break}
  case 'grp':{const c=db.chats[d.chat];if(!c||c.type!=='group'||c.pub)return;
    if(d.op==='leave'){if(c.owner===u.id)return err('سازنده نمی‌تواند خارج شود؛ گروه را حذف کنید');
      c.members=c.members.filter(x=>x!==u.id);c.admins=c.admins.filter(x=>x!==u.id);save();toUser(u.id,{t:'chatdel',id:c.id});pushChat(c);return}
    if(!isGA(c))return err('دسترسی ندارید');const t=db.users[d.user];
    if(d.op==='add'&&t&&!c.members.includes(t.id)&&!t.blocked.includes(u.id))c.members.push(t.id);
    else if(d.op==='rm'&&t&&t.id!==c.owner){c.members=c.members.filter(x=>x!==t.id);c.admins=c.admins.filter(x=>x!==t.id);toUser(t.id,{t:'chatdel',id:c.id})}
    else if(d.op==='admin'&&t&&(c.owner===u.id||adm)&&c.members.includes(t.id))c.admins=c.admins.includes(t.id)?c.admins.filter(x=>x!==t.id):[...c.admins,t.id];
    else if(d.op==='lock')c.locked=!c.locked;
    else if(d.op==='rename'&&clean(d.val,30).length>1)c.name=clean(d.val,30);
    else if(d.op==='avatar')c.avatar=okUrl(d.val)?d.val:Array.from(clean(d.val,12)).slice(0,2).join('');
    else if(d.op==='delete'&&(c.owner===u.id||adm)){const ms=c.members.slice();delete db.chats[c.id];db.msgs=db.msgs.filter(m=>m.chat!==c.id);save();ms.forEach(id=>toUser(id,{t:'chatdel',id:c.id}));return}
    save();pushChat(c);break}
  case 'a_auth':if(d.key===ADMIN_KEY){ws.adm=true;send(ws,{t:'a_ok'})}else err('کلید مدیریت اشتباه است');break;
  case 'a_stats':if(!adm)return;send(ws,{t:'a_stats',s:{users:Object.keys(db.users).length,online:clients.size,msgs:db.msgs.length,chats:Object.keys(db.chats).length,banned:Object.values(db.users).filter(x=>x.banned).length}});break;
  case 'a_users':if(!adm)return;send(ws,{t:'a_users',u:Object.values(db.users).map(x=>({id:x.id,name:x.name,banned:!!x.banned,mod:!!x.mod,online:clients.has(x.id)}))});break;
  case 'a_ban':{if(!adm)return;const t=db.users[d.user];if(!t)return;t.banned=!!d.v;save();
    if(t.banned)(clients.get(t.id)||[]).forEach(w=>{send(w,{t:'banned'});w.sock.end()});break}
  case 'a_mod':{if(!full)return;const t=db.users[d.user];if(t){t.mod=!!d.v;save();toAll({t:'user',u:pub(t)})}break}
  case 'a_chats':if(!adm)return;send(ws,{t:'a_chats',c:Object.values(db.chats).filter(c=>c.type==='group').map(c=>({id:c.id,name:c.name,n:c.pub?'همه':c.members.length}))});break;
  case 'a_set':if(!full)return;db.settings.siteName=clean(d.siteName,30)||'گپینو';db.settings.announce=clean(d.announce,200);
    db.settings.maxUpload=Math.min(20,Math.max(1,+d.maxUpload||5));save();toAll({t:'settings',s:db.settings});break;
  }
}
srv.listen(PORT,()=>{console.log('GAPINO running → http://localhost:'+PORT);if(ADMIN_KEY==='admin123')console.log('⚠️  کلید مدیریت پیش‌فرض است؛ با ADMIN_KEY=... تغییرش بده')});
